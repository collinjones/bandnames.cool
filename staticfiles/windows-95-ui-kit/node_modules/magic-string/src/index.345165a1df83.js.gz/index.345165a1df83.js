import MagicString from './MagicString.js';
import Bundle from './Bundle.js';

MagicString.Bundle = Bundle;

export default MagicString;
