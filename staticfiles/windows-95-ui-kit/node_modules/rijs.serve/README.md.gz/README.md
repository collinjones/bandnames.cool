# Ripple | Serve
[![Coverage Status](https://coveralls.io/repos/rijs/serve/badge.svg?branch=master&service=github)](https://coveralls.io/github/rijs/serve?branch=master)
[![Build Status](https://travis-ci.org/rijs/serve.svg)](https://travis-ci.org/rijs/serve)

Exposes the distribution files as endpoints on your server.