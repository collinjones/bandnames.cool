# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

<a name="1.5.0"></a>
# 1.5.0 (2018-11-30)


### Bug Fixes

* **package:** update yargs to version 10.0.3 ([f1eb4cb](https://github.com/yargs/yargs-unparser/commit/f1eb4cb))
* **package:** update yargs to version 11.0.0 ([6aa7c91](https://github.com/yargs/yargs-unparser/commit/6aa7c91))


### Features

* add interoperation with minimist ([ba477f5](https://github.com/yargs/yargs-unparser/commit/ba477f5))



<a name="1.4.0"></a>
# [1.4.0](https://github.com/moxystudio/yargs-unparser/compare/v1.3.0...v1.4.0) (2017-12-30)


### Features

* add interoperation with minimist ([ba477f5](https://github.com/moxystudio/yargs-unparser/commit/ba477f5))
