module.exports = require('utilise/client') 
  ? require('./client') 
  : require('./server')