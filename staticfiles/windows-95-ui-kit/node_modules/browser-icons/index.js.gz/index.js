module.exports = [
  require('icon-ios')
, require('icon-linux')
, require('icon-android')
, require('icon-chrome')
, require('icon-firefox')
, require('icon-ie')
, require('icon-opera')
, require('icon-osx')
, require('icon-safari')
, require('icon-windows')
]