# Ripple | Singleton
[![Coverage Status](https://coveralls.io/repos/rijs/singleton/badge.svg?branch=master&service=github)](https://coveralls.io/github/rijs/singleton?branch=master)
[![Build Status](https://travis-ci.org/rijs/singleton.svg)](https://travis-ci.org/rijs/singleton)

Exposes the instance globally on `(window || global).ripple`.