# Ripple | Pages
[![Coverage Status](https://coveralls.io/repos/rijs/pages/badge.svg?branch=master&service=github)](https://coveralls.io/github/rijs/pages?branch=master)
[![Build Status](https://travis-ci.org/rijs/pages.svg)](https://travis-ci.org/rijs/pages)

Statically serves your '/pages' directory