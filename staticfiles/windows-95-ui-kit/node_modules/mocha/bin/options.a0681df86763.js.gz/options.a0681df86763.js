'use strict';

/*
 * This module is deprecated and will be removed in a future version of Mocha.
 * @deprecated Deprecated in v6.0.0; source moved into {@link module:lib/cli/options lib/cli/options module}.
 * @module
 * @exports module:lib/cli/options
 */

module.exports = require('../lib/cli/options');
