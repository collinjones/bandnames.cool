'use strict';

/**
 * Just exports {@link module:lib/cli/cli} for convenience.
 * @private
 * @module lib/cli
 * @exports module:lib/cli/cli
 */
module.exports = require('./cli');
