module.exports = { 
  browserstack: require('./browserstack')
, saucelabs: require('./saucelabs') 
}