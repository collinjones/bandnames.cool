# Installation
> `npm install --save @types/tough-cookie`

# Summary
This package contains type definitions for tough-cookie (https://github.com/salesforce/tough-cookie).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/tough-cookie

Additional Details
 * Last updated: Thu, 17 Jan 2019 23:41:53 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Leonard Thieu <https://github.com/leonard-thieu>, LiJinyao <https://github.com/LiJinyao>, Michael Wei <https://github.com/no2chem>.
