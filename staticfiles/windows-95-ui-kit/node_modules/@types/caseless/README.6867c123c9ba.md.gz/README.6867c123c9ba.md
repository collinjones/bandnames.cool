# Installation
> `npm install --save @types/caseless`

# Summary
This package contains type definitions for caseless ( https://github.com/mikeal/caseless ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/caseless

Additional Details
 * Last updated: Mon, 11 Mar 2019 18:30:09 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by downace <https://github.com/downace>, Matt R. Wilson <https://github.com/mastermatt>, Emily Klassen <https://github.com/forivall>.
