var last = require('./last')
  , set = require('./set')
  , is = require('./is')

module.exports = function pop(o){
  return is.arr(o) 
       ? set({ key: o.length - 1, value: last(o), type: 'remove' })(o)
       : o 
}