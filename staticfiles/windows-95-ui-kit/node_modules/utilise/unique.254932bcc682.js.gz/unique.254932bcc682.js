var is = require('./is')

module.exports = function unique(d, i){
  if (!i) unique.matched = []
  return !is.in(unique.matched)(d) 
       ? unique.matched.push(d)
       : false 
}
