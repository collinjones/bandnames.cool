console.log('in main.js: ' + JSON.stringify({
    __filename: __filename,
    __dirname: __dirname
}));

require('./foo');
