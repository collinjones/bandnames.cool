function clicked () {
    var submit_button = document.getElementById("bandname-submit")
    submit_button.src="static/images/button-clicked.png"
}
function resting () {
    var submit_button = document.getElementById("bandname-submit")
    submit_button.src="static/images/button.png"
}

function dragged () {
    var submit_button = document.getElementById("bandname-submit")
    submit_button.src="static/images/button.png"
}