// $(document).ready(function () {
//     var currentTime = new Date();

//     $.ajax({
//         type: 'POST',
//         url: '/set_timezone_cookie',
//         data: {
//             currentTime: currentTime,
//             csrfmiddlewaretoken: $('input[name=csrfmiddlewaretoken]').val(),
//         },
//         // success: function (data) {
            
//         // }
//     }); 
// });