function clicked() {
    var submit_button = document.getElementById("bandname-submit")
    submit_button.src="static/images/button-clicked.png"
}
function resting() {
    var submit_button = document.getElementById("bandname-submit")
    submit_button.src="static/images/button.png"
}

function dragged() {
    var submit_button = document.getElementById("bandname-submit")
    submit_button.src="static/images/button.png"
}

function vote_up_clicked() {
    var submit_button = document.getElementById("upvote-button")
    submit_button.src="static/images/uv2.png"
}

function vote_down_clicked() {
    var submit_button = document.getElementById("downvote-button")
    submit_button.src="static/images/dv2.png"
}

function vote_up_resting() {
    var submit_button = document.getElementById("upvote-button")
    submit_button.src="static/images/uv1.png"
}

function vote_down_resting() {
    var submit_button = document.getElementById("downvote-button")
    submit_button.src="static/images/dv1.png"
}

function vote_up_dragged() {
    var submit_button = document.getElementById("upvote-button")
    submit_button.src="static/images/uv1.png"
}

function vote_down_dragged() {
    var submit_button = document.getElementById("downvote-button")
    submit_button.src="static/images/dv1.png"
}